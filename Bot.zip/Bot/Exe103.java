import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe103 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		ehFim(ABAIXO);
		diga("Cheguei!");
	}
	public static void main(String[] args) {
		MundoVisual.iniciar("Exe103.xml");

	}
}
