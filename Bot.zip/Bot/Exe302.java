import org.omg.CORBA.Environment;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe302 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		while(!ehFim(DIREITA)) {
			if(ehVazio(DIREITA)) {
				andarDireita();
			}
			else {
				andarAbaixo();
			}
			if((ehVazio(ABAIXO))&& (!ehVazio(DIREITA))) {
				andarAbaixo();
			}
			if((!ehVazio(ABAIXO))&& (!ehVazio(DIREITA))) {
				diga("N�o atingir o objetivo!");
			}
			if(ehFim(DIREITA)&&ehVazio(ACIMA)&& !ehFim(ACIMA)) {
				andarAcima();
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MundoVisual.iniciar("Exe302.xml");
	}

}
