import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe104 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		
		while(!ehFim(DIREITA)) {
			andarDireita();
			
		}
		diga("Cheguei!");
		
		while(!ehFim(ABAIXO)) {
			andarAbaixo();
			
		} 
		diga("Cheguei!");
		
		while(!ehFim(ESQUERDA)) {
			andarEsquerda();
			
		}
		
		diga("Cheguei!");
		
		while(!ehFim(ACIMA)) {
			andarAcima();
			
		}
		diga("Cheguei!");
		
	}
	public static void main(String[] args) {
		MundoVisual.iniciar("Exe104.xml");

	}
}
