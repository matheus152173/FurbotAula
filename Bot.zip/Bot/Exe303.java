import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.Mundo;

public class Exe303 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		int alien = 0;
		int x = getX();
		int y = getY();
		//andarAte();
		
		while(!ehFim(DIREITA)) {
			andarDireita();
			
			if(ehObjetoDoMundoTipo("Alien", AQUIMESMO)) {
				alien = alien + 1;
			}
		}
		while(!ehFim(ABAIXO)) {
			andarAbaixo();
		if(ehObjetoDoMundoTipo("Alien", AQUIMESMO)) {
				alien = alien +1;
			}
		}
		while(!ehFim(ESQUERDA)) {
			andarEsquerda();
			if(ehObjetoDoMundoTipo("Alien", AQUIMESMO)) {
				alien = alien + 1;
			}
		}
		while(!ehFim(ACIMA)) {
			andarAcima();
			if(ehObjetoDoMundoTipo("Alien", AQUIMESMO)) {
				alien = alien + 1;
			}
		}
		while(getX()!= x) {
			andarDireita();
		}
		while(getY() != y) {
			andarAbaixo();
		}
		if(ehObjetoDoMundoTipo("Alien", AQUIMESMO)) {
			alien = alien +1;
		}
		diga("Chegue"+alien);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MundoVisual.iniciar("Exe303.xml");
	}

}
