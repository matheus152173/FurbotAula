import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe301 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		while(!ehFim(DIREITA)) {
			if(ehVazio(DIREITA)) {
				andarDireita();
			}
			else {
				andarAbaixo();
			}
			if(ehFim(DIREITA)) {
				andarAcima();
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MundoVisual.iniciar("Exe301.xml");
	}

}
