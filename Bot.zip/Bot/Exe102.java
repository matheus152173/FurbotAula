import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe102 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		andarDireita();
		andarDireita();
		andarDireita();
		ehFim(DIREITA);
		diga("Cheguei!");
		
	}
	public static void main(String[] args) {
		MundoVisual.iniciar("Exe102.xml");

	}

}
