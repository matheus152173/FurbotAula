import org.apache.commons.beanutils.Converter;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.ObjetoDoMundo;

public class Exe304 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		limparConsole();
		
		// PARA DIREITA
		int passos = 0;
		while(!ehFim(DIREITA)) {
			if(ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
				Numero numero = (Numero) getObjeto(AQUIMESMO);
				passos += numero.getValor();
				passos = passos += 1;
			}
			andarDireita();
		}
		
		diga("Passos: " + passos);
		
		//PARA BAIXO
		passos = 0;
		while(!ehFim(ABAIXO)) {
			if(ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
				passos = passos += 1;
			}
			andarAbaixo();
		}
		diga("Passos: "+ passos);
		
		passos = 0;
		while(!ehFim(ESQUERDA)) {
			if(ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
				passos = passos += 1;
			}
			andarEsquerda();
		}
		diga("Passos: "+ passos);
		
		passos = 0;
		while(!ehFim(ACIMA)) {
			if(ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
				passos = passos += 1;
			}
			andarAcima();
		}
		diga("Passos: "+ passos);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MundoVisual.iniciar("Exe304.xml");
	}

}
