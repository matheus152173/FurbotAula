import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe105 extends Furbot {

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		
		
	}
	public static void main(String[] args) {
		MundoVisual.iniciar("Exe105.xml");

	}


}
