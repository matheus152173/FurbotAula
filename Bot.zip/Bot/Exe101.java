import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Exe101 extends Furbot {

	public static void main(String[] args) {
		MundoVisual.iniciar("Exe101.xml");

	}

	@Override
	public void inteligencia() throws Exception {
		// TODO Auto-generated method stub
		andarDireita();
		andarAbaixo();
		andarEsquerda();
		diga("Cheguei!");
		
	}

}
